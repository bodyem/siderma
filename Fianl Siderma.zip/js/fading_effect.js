var where;
var count;
var  max;
var wherex = 'fading_images';
var visible_item;
function push(){}

function schimb(x){
	
	wherex=x.getAttribute('target');
	document.getElementById(wherex).style.display='inline';
	my_divs = document.getElementsByTagName('div');
	for(i=0;i<my_divs.length;i++){
		if (my_divs[i].getAttribute('id')!=null && my_divs[i].getAttribute('id').indexOf('fading_images')!=-1)
			my_divs[i].style.display='none';
					
	}
	
	stil=document.getElementById(wherex);
	stil.style.display='inline';
	max=$(stil).children().length;
	count=1;
	change(count,wherex);
}
			
function change(count,who){
	console.log('ok');
	$($(document.getElementById(who)).children()[count-1]).stop(true,true).fadeIn(4000);
	$($(document.getElementById(who)).children()[count-1]).stop(true,true).fadeOut(2000);
	$($(document.getElementById(who)).children()[count]).stop(true,true).fadeIn(4000);
	
	
	
}
			
			
			
function change_wait(obj){
	alert(count);
	if(count==max)
		 count=1;
	setTimeout(change(obj,count),1000);
}
			

$(document).ready(function(){
	count=1;
	where = $("#fading_images").attr('ext');
	max=$("#fading_images").children().length;
	console.log("max : ",max);
	obj=$("#fading_images").children()[0];
	change(count,'fading_images');			
});
